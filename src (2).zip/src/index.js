const Orchestrator = require('./orchestrator');

async function main() {
  const args = process.argv.slice(2);
  let companyName = '';

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--company' && args[i + 1]) {
      companyName = args[i + 1];
      break;
    }
  }

  if (!companyName) {
    console.error('Usage: node src/index.js --company "Company Name"');
    console.error('Example: node src/index.js --company "Apollo Hospitals"');
    process.exit(1);
  }

  console.log('==================================================');
  console.log(`🚀 VENTURA V2 CLI`);
  console.log(`🎯 Target Company: ${companyName}`);
  console.log('==================================================');

  const orchestrator = new Orchestrator(companyName);
  
  const startTime = Date.now();
  
  try {
     await orchestrator.runAgents();
     
     const endTime = Date.now();
     const durationSec = ((endTime - startTime) / 1000).toFixed(1);
     
     console.log('\n==================================================');
     console.log(`✅ REPORT GENERATED SUCCESSFULLY`);
     console.log(`⏱️  Duration: ${durationSec}s`);
     
     const fs = require('fs');
     if (fs.existsSync('ventura_run_telemetry.json')) {
        const telemetry = JSON.parse(fs.readFileSync('ventura_run_telemetry.json', 'utf8'));
        if (telemetry.runSummary) {
           console.log(`📊 Total LLM Tokens: ${telemetry.runSummary.totalTokens}`);
           console.log(`📈 Agents Executed: ${telemetry.runSummary.agentsRun}`);
           console.log(`⚠️ Agents Failed: ${telemetry.runSummary.agentsFailed}`);
           console.log(`🔗 Citations Tracked: ${telemetry.runSummary.totalCitations}`);
        }
     }
     console.log(`📄 PATH: ${companyName.replace(/ /g, '_')}_Equity_Research.pdf`);
     console.log('==================================================');
     
  } catch (e) {
     console.error('\n❌ PIPELINE FAILED:', e.message);
     process.exit(1);
  }
}

main();
