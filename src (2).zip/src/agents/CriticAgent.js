const BaseAgent = require('../BaseAgent');

class CriticAgent extends BaseAgent {
  constructor() {
    super(
      'CriticAgent',
      'You are the Chief Editor and Critic. Your job is to evaluate a draft equity research report section. Check for: missing sections, unsupported claims, repeated content, logical contradictions, poor structure, and missing citations. If the draft is good, respond with "APPROVED". If there are issues, list them clearly so the Writer can revise.'
    );
  }

  async run(companyName, draftText, options = {}) {
    console.log(`[CriticAgent] Evaluating draft for ${companyName}...`);
    
    const userPrompt = `
    Company: ${companyName}
    
    Draft Text:
    ${draftText}

    Evaluate the draft. Output 'APPROVED' if it requires no changes. Otherwise, provide a concise list of corrections needed.
    `;

    return await this.execute(userPrompt, options);
  }
}

module.exports = CriticAgent;
