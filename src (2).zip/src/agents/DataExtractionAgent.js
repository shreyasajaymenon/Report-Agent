const BaseAgent = require('../BaseAgent');
const searchUtils = require('../searchUtils');

class DataExtractionAgent extends BaseAgent {
  constructor() {
    super(
      'DataExtractionAgent',
      `You are a strict JSON Financial Data Extraction Agent. Your ONLY job is to extract exact financial numbers for the requested company and return them in a specific JSON format. Do NOT output any markdown, explanations, or text outside the JSON block. You must return valid JSON. If exact 5-year data is not available in the context, DO NOT fabricate or guess numbers. Leave them as null or 0 if appropriate.`
    );
  }

  async run(companyName, context, options = {}) {
    console.log(`[DataExtractionAgent] Extracting hard JSON financial data for ${companyName}...`);
    
    const searchContext = await searchUtils.searchAndScrape(
      `${companyName} screener.in financial results sales ebitda net profit 5 years`
    );

    const userPrompt = `
    Company: ${companyName}
    Search Context:
    ${searchContext}

    Extract the financials and output strictly the required JSON block.
    Ensure you output a valid JSON containing:
    ticker, cmp, market_cap_cr, pe_ratio, book_value, roce, roe, target, financials (years, sales, ebitda, net_profit, cfo, cfi, fcf arrays), balance_sheet (equity, reserves, borrowings, fixed_assets arrays), ratios (roce_pct, roe_pct, debt_equity arrays), peers (names, ev_ebitda arrays).
    DO NOT FABRICATE DATA.
    `;

    // We can rely on BaseAgent's execution framework to handle retries and JSON formatting
    // But since we didn't inject a strict Zod schema for this specific legacy python consumer, we'll just parse manually.
    try {
      let response = await this.execute(userPrompt, options);
      if (!response) return null;
      
      // Attempt manual parse if not schema validated
      if (typeof response === 'string') {
         response = response.replace(/```json/g, '').replace(/```/g, '').trim();
         return JSON.parse(response);
      }
      return response;
    } catch (error) {
      console.error(`[DataExtractionAgent] Execution failed:`, error.message);
      // DO NOT fabricate fallback financial numbers. Fail gracefully.
      return null;
    }
  }
}

module.exports = DataExtractionAgent;
