const { z } = require('zod');

// Shared schema for all agents to output a common fact format
const FactSchema = z.object({
  claim: z.string().describe("The factual claim extracted."),
  sourceUrl: z.string().url().describe("The URL where this fact was found."),
  evidence: z.string().describe("Direct quote or data point supporting the claim."),
  valuationImpact: z.string().optional().describe("How this impacts valuation (e.g., 'Positive', 'Negative', 'Neutral').")
});

const FinancialDataSchema = z.object({
  revenue: z.number().optional(),
  netIncome: z.number().optional(),
  debt: z.number().optional(),
  cashFlow: z.number().optional(),
  ratios: z.record(z.number()).optional(), // e.g., { "PE": 15.5, "PB": 2.1 }
  facts: z.array(FactSchema)
});

const GovernanceDataSchema = z.object({
  boardIndependence: z.string().optional(),
  auditorRemarks: z.string().optional(),
  facts: z.array(FactSchema)
});

const CompanyStateSchema = z.object({
  companyName: z.string(),
  status: z.enum(['initializing', 'gathering', 'writing', 'completed', 'error']),
  financials: FinancialDataSchema.optional(),
  governance: GovernanceDataSchema.optional(),
  industry: z.object({ facts: z.array(FactSchema) }).optional(),
  macro: z.object({ facts: z.array(FactSchema) }).optional(),
  competitors: z.object({ facts: z.array(FactSchema) }).optional(),
  news: z.object({ facts: z.array(FactSchema) }).optional(),
  errors: z.array(z.string()).optional()
});

module.exports = {
  FactSchema,
  FinancialDataSchema,
  GovernanceDataSchema,
  CompanyStateSchema
};
