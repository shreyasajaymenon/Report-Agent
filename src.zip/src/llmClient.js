require('dotenv').config();
const { OpenAI } = require('openai');

class LLMClient {
  constructor() {
    // We instantiate OpenAI client optionally
    if (process.env.OPENAI_API_KEY) {
      this.openaiClient = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY,
      });
    }

    // Discover all OpenRouter API keys in .env (e.g. OPENROUTER_API_KEY_1, OPENROUTER_API_KEY_2, etc.)
    this.openRouterKeys = Object.keys(process.env)
      .filter(key => key.startsWith('OPENROUTER_API_KEY'))
      .map(key => process.env[key]);
      
    if (this.openRouterKeys.length === 0) {
      console.warn('[LLMClient] No OPENROUTER_API_KEY found in .env!');
    }
    
    this.currentKeyIndex = 0;
    this.currentModelIndex = 0;

    // A list of reliable free models to cycle through to distribute load
    this.fallbackModels = [
      'tencent/hy3:free'
    ];
  }
  
  getOpenRouterClient() {
    const key = this.openRouterKeys[this.currentKeyIndex];
    // Rotate to the next key for the next request
    this.currentKeyIndex = (this.currentKeyIndex + 1) % this.openRouterKeys.length;
    
    return new OpenAI({
      baseURL: 'https://openrouter.ai/api/v1',
      apiKey: key,
      defaultHeaders: {
        'HTTP-Referer': 'http://localhost:3000',
        'X-Title': 'Report Agent Swarm',
      }
    });
  }

  async getCompletion(options, useOpenRouter = true) {
    if (!useOpenRouter && !this.openaiClient) {
      throw new Error('Requested OpenAI client is not configured. Missing API key in .env file.');
    }
    
    let retries = 10;
    let delay = 2000;

    while (retries > 0) {
      try {
        const client = useOpenRouter ? this.getOpenRouterClient() : this.openaiClient;
        
        // Globally rotate model to distribute load across different free providers
        const modelToUse = options.model || this.fallbackModels[this.currentModelIndex];
        this.currentModelIndex = (this.currentModelIndex + 1) % this.fallbackModels.length;
        
        console.log(`[LLMClient] Routing request to model: ${modelToUse}`);
        
        const response = await client.chat.completions.create({
          model: modelToUse,
          messages: options.messages,
          temperature: options.temperature || 0.2, 
          tools: options.tools
        });

        if (!response || !response.choices || response.choices.length === 0) {
          throw new Error(`Invalid response structure from OpenRouter: ${JSON.stringify(response)}`);
        }

        return response.choices[0].message;
      } catch (error) {
        const isRateLimit = error.status === 429 || error.status === 502 || error.status === 524 ||
                            (error.message && error.message.includes('ResourceExhausted')) ||
                            (error.message && error.message.includes('Invalid response structure')) ||
                            (error.message && error.message.includes('ECONNRESET')) ||
                            (error.message && error.message.includes('fetch failed')) ||
                            (error.message && error.message.includes('terminated'));
                            
        const isModelDown = error.status === 404 || (error.message && error.message.includes('No endpoints found'));
        
        if ((isRateLimit || isModelDown) && retries > 1) {
          // If we hit a rate limit or a dead endpoint, rotate the API key and the model
          // Note: getOpenRouterClient() already rotated the key for the next try
          
          console.log(`[LLMClient] Issue hit (${isModelDown ? 'Model Down' : 'Rate Limit'}). Retrying in ${delay / 1000}s...`);
          await new Promise(res => setTimeout(res, delay));
          retries--;
          delay *= 1.5; 
        } else {
          console.error('[LLMClient] Error generating completion:', error.message);
          throw error;
        }
      }
    }
  }
}

module.exports = new LLMClient();
