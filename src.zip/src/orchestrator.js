const StateManager = require('./stateManager');
const PDFGenerator = require('./pdfGenerator');

// Import all 22 agents
const ChiefResearchOfficerAgent = require('./agents/ChiefResearchOfficerAgent');
const PlannerAgent = require('./agents/PlannerAgent');
const DiscoveryAgent = require('./agents/DiscoveryAgent');
const NSEAgent = require('./agents/NSEAgent');
const BSEAgent = require('./agents/BSEAgent');
const CompanyIRAgent = require('./agents/CompanyIRAgent');
const AnnualReportAgent = require('./agents/AnnualReportAgent');
const QuarterlyAgent = require('./agents/QuarterlyAgent');
const TranscriptAgent = require('./agents/TranscriptAgent');
const PresentationAgent = require('./agents/PresentationAgent');
const GovernanceAgent = require('./agents/GovernanceAgent');
const FinancialEngine = require('./agents/FinancialEngine');
const RatioEngine = require('./agents/RatioEngine');
const IndustryAgent = require('./agents/IndustryAgent');
const CompetitionAgent = require('./agents/CompetitionAgent');
const ValuationAgent = require('./agents/ValuationAgent');
const RiskAgent = require('./agents/RiskAgent');
const InvestmentCommittee = require('./agents/InvestmentCommittee');
const ChiefWriter = require('./agents/ChiefWriter');
const Editor = require('./agents/Editor');
const Formatter = require('./agents/Formatter');
const VerificationAgent = require('./agents/VerificationAgent');
const DataExtractionAgent = require('./agents/DataExtractionAgent');

class Orchestrator {
  constructor(companyName) {
    this.companyName = companyName;
    this.stateManager = new StateManager(companyName);
  }

  async runAgents() {
    console.log(`[Orchestrator] Starting 22-Agent Waterfall Pipeline for ${this.companyName}`);
    this.stateManager.updateState('status', 'processing');

    try {
      let currentState = { company: this.companyName, data: {} };

      // Helper function to verify agent output
      const verify = async (draft) => {
        return await new VerificationAgent().verify(this.companyName, draft);
      };

      // Phase 1: Leadership & Planning (Sequential)
      currentState.data.cro = await new ChiefResearchOfficerAgent().run(this.companyName, currentState);
      currentState.data.planner = await new PlannerAgent().run(this.companyName, currentState);

      console.log('[Orchestrator] Launching Phase 2 Data Gathering Agents (Concurrent)...');
      // Phase 2: Discovery & Data Acquisition (Concurrent)
      const phase2Results = await Promise.all([
        new DiscoveryAgent().run(this.companyName, currentState),
        new NSEAgent().run(this.companyName, currentState),
        new BSEAgent().run(this.companyName, currentState),
        new CompanyIRAgent().run(this.companyName, currentState),
        new AnnualReportAgent().run(this.companyName, currentState),
        new QuarterlyAgent().run(this.companyName, currentState),
        new TranscriptAgent().run(this.companyName, currentState),
        new PresentationAgent().run(this.companyName, currentState)
      ]);
      
      currentState.data.discovery = await verify(phase2Results[0]);
      currentState.data.nse = await verify(phase2Results[1]);
      currentState.data.bse = await verify(phase2Results[2]);
      currentState.data.companyIR = await verify(phase2Results[3]);
      currentState.data.annualReport = await verify(phase2Results[4]);
      currentState.data.quarterly = await verify(phase2Results[5]);
      currentState.data.transcript = await verify(phase2Results[6]);
      currentState.data.presentation = await verify(phase2Results[7]);

      console.log('[Orchestrator] Launching Phase 3 Analytical Engines (Concurrent)...');
      // Phase 3: The Analytical Engine (Concurrent)
      const phase3Results = await Promise.all([
        new GovernanceAgent().run(this.companyName, currentState),
        new FinancialEngine().run(this.companyName, currentState),
        new RatioEngine().run(this.companyName, currentState),
        new IndustryAgent().run(this.companyName, currentState),
        new CompetitionAgent().run(this.companyName, currentState),
        new ValuationAgent().run(this.companyName, currentState),
        new RiskAgent().run(this.companyName, currentState)
      ]);

      currentState.data.governance = await verify(phase3Results[0]);
      this.stateManager.updateState('governance', currentState.data.governance);
      
      currentState.data.financial = await verify(phase3Results[1]);
      currentState.data.ratio = await verify(phase3Results[2]);
      
      currentState.data.industry = await verify(phase3Results[3]);
      this.stateManager.updateState('industry', currentState.data.industry);
      
      currentState.data.competition = await verify(phase3Results[4]);
      currentState.data.valuation = await verify(phase3Results[5]);
      currentState.data.risk = await verify(phase3Results[6]);

      console.log('[Orchestrator] Launching Phase 4 Synthesis (Sequential)...');
      // Phase 4: Synthesis & Output (Sequential as they rely on finalized data)
      currentState.data.investmentCommittee = await new InvestmentCommittee().run(this.companyName, currentState);
      
      let finalDraft = await new ChiefWriter().run(this.companyName, currentState);
      let editedDraft = await new Editor().run(this.companyName, finalDraft);
      let finalFormattedText = await new Formatter().run(this.companyName, editedDraft);

      console.log('[Orchestrator] Running DataExtractionAgent for JSON financials...');
      const dataInputJSON = await new DataExtractionAgent().run(this.companyName);

      console.log('[Orchestrator] Pipeline execution completed. Handing over to Python Generator...');
      
      // Save data for Python
      const fs = require('fs');
      const execSync = require('child_process').execSync;
      
      const payload = {
        companyName: this.companyName,
        sections: {
          cro: currentState.data.cro,
          planner: currentState.data.planner,
          discovery: currentState.data.discovery,
          nse: currentState.data.nse,
          bse: currentState.data.bse,
          companyIR: currentState.data.companyIR,
          annualReport: currentState.data.annualReport,
          quarterly: currentState.data.quarterly,
          transcript: currentState.data.transcript,
          presentation: currentState.data.presentation,
          governance: currentState.data.governance,
          financial: currentState.data.financial,
          ratio: currentState.data.ratio,
          industry: currentState.data.industry,
          competition: currentState.data.competition,
          valuation: currentState.data.valuation,
          risk: currentState.data.risk,
          investmentCommittee: currentState.data.investmentCommittee,
          finalText: finalFormattedText
        },
        DATA_INPUT: dataInputJSON
      };
      
      fs.writeFileSync('report_data.json', JSON.stringify(payload, null, 2));
      
      // Execute Python
      console.log(execSync('python src/equity_report_template.py').toString());

      this.stateManager.updateState('status', 'completed');
    } catch (error) {
      console.error('[Orchestrator] Workflow failed:', error);
      this.stateManager.updateState('status', 'error');
    }
  }
}

module.exports = Orchestrator;
