const { CompanyStateSchema } = require('./schemas');

class StateManager {
  constructor(companyName) {
    this.state = {
      companyName,
      status: 'initializing',
      facts: []
    };
  }

  updateState(section, data) {
    this.state[section] = data;
    console.log(`[StateManager] Updated section: ${section}`);
  }

  addError(errorMsg) {
    if (!this.state.errors) this.state.errors = [];
    this.state.errors.push(errorMsg);
  }

  getState() {
    return this.state;
  }

  validateState() {
    return CompanyStateSchema.safeParse(this.state);
  }
}

module.exports = StateManager;
