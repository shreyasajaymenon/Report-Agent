const BaseAgent = require('../BaseAgent');
const searchUtils = require('../searchUtils');

class VerificationAgent extends BaseAgent {
  constructor() {
    super(
      'VerificationAgent',
      'You are a rigorous Fact-Checking and Verification Agent. Your job is to review the provided equity research text, cross-check it against the real-time data provided in the context, and output a corrected, highly accurate version of the text. Do NOT add any conversational filler. Do NOT use bold text (`**`). Just output the corrected paragraphs. Ensure no false data or hallucinated numbers exist. If the original text is accurate, return it largely as is but still adhering to the formatting rules.'
    );
  }

  async verify(companyName, draftText) {
    try {
      console.log(`[VerificationAgent] Verifying content for ${companyName}...`);
      
      // We grab some live context to help the verification agent
      const searchContext = await searchUtils.searchAndScrape(
        `${companyName} latest financials revenue profit margin 2024 2025`
      );

      const systemPrompt = this.basePrompt;
      const userPrompt = `
      Company: ${companyName}
      Live Search Context:
      ${searchContext}

      Original Draft Text to Verify:
      ${draftText}

      Please provide the corrected, 100% accurate version of the text. Do not use bold tags. Do not hallucinate numbers. Use the live context to correct any discrepancies. Output ONLY the text.
      `;

      return await this.invoke(userPrompt);
    } catch (error) {
      console.error(`[VerificationAgent] Execution failed:`, error.message);
      return draftText; // Fallback to original text if verification fails
    }
  }
}

module.exports = VerificationAgent;
