const BaseAgent = require('../BaseAgent');
const searchUtils = require('../searchUtils');

class DataExtractionAgent extends BaseAgent {
  constructor() {
    super(
      'DataExtractionAgent',
      `You are a strict JSON Financial Data Extraction Agent. Your ONLY job is to extract exact financial numbers for the requested company and return them in a specific JSON format. Do NOT output any markdown, explanations, or text outside the JSON block. You must return valid JSON. If exact 5-year data is not available in the context, provide your best accurate estimates based on the company's size and sector.
      
Format exactly like this:
{
  "ticker": "TCS",
  "cmp": 3900,
  "market_cap_cr": 1400000,
  "pe_ratio": 30.5,
  "book_value": 300,
  "roce": 45.2,
  "roe": 38.4,
  "target": 4200,
  "financials": {
    "years": ["FY21", "FY22", "FY23", "FY24", "FY25"],
    "sales": [164177, 191754, 225458, 240893, 250000],
    "ebitda": [46546, 53047, 59259, 62000, 65000],
    "net_profit": [32430, 38327, 42147, 46199, 48000],
    "cfo": [38000, 40000, 41000, 42000, 45000],
    "cfi": [-5000, -6000, -7000, -8000, -9000],
    "fcf": [33000, 34000, 34000, 34000, 36000]
  },
  "balance_sheet": {
    "equity": [300, 300, 300, 300, 300],
    "reserves": [85000, 90000, 95000, 100000, 110000],
    "borrowings": [0, 0, 0, 0, 0],
    "fixed_assets": [20000, 21000, 22000, 23000, 24000]
  },
  "ratios": {
    "roce_pct": [45, 46, 47, 45, 45],
    "roe_pct": [38, 39, 40, 38, 38],
    "debt_equity": [0, 0, 0, 0, 0]
  },
  "peers": {
    "names": ["Peer 1", "Peer 2", "Peer 3", "Target Co"],
    "ev_ebitda": [30, 28, 25, 32]
  }
}`
    );
  }

  async run(companyName) {
    try {
      console.log(`[DataExtractionAgent] Extracting hard JSON financial data for ${companyName}...`);
      
      const searchContext = await searchUtils.searchAndScrape(
        `${companyName} screener.in financial results sales ebitda net profit 5 years`
      );

      const systemPrompt = this.basePrompt;
      const userPrompt = `
      Company: ${companyName}
      Search Context:
      ${searchContext}

      Extract the financials and output strictly the required JSON block.
      `;

      let response = await this.invoke(userPrompt);
      
      // Clean up markdown ticks if present
      response = response.replace(/```json/g, '').replace(/```/g, '').trim();
      
      return JSON.parse(response);
    } catch (error) {
      console.error(`[DataExtractionAgent] Execution failed:`, error.message);
      // Fallback dummy JSON
      return {
        "ticker": "UNKNOWN",
        "cmp": 100,
        "market_cap_cr": 10000,
        "pe_ratio": 20,
        "book_value": 50,
        "roce": 15,
        "roe": 15,
        "target": 120,
        "financials": {
          "years": ["FY21", "FY22", "FY23", "FY24", "FY25"],
          "sales": [1000, 1100, 1200, 1300, 1400],
          "ebitda": [200, 220, 240, 260, 280],
          "net_profit": [100, 110, 120, 130, 140],
          "cfo": [110, 120, 130, 140, 150],
          "cfi": [-50, -60, -70, -80, -90],
          "fcf": [60, 60, 60, 60, 60]
        },
        "balance_sheet": {
          "equity": [10, 10, 10, 10, 10],
          "reserves": [100, 110, 120, 130, 140],
          "borrowings": [0, 0, 0, 0, 0],
          "fixed_assets": [50, 60, 70, 80, 90]
        },
        "ratios": {
          "roce_pct": [15, 15, 15, 15, 15],
          "roe_pct": [15, 15, 15, 15, 15],
          "debt_equity": [0.1, 0.1, 0.1, 0.1, 0.1]
        },
        "peers": {
          "names": ["Peer 1", "Peer 2", "Peer 3", "Target Co"],
          "ev_ebitda": [15, 12, 10, 14]
        }
      };
    }
  }
}

module.exports = DataExtractionAgent;
