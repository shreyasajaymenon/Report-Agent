const axios = require('axios');

class FetchUtils {
  static async fetchWithRetry(url, options = {}, retries = 3) {
    for (let i = 0; i < retries; i++) {
      try {
        const response = await axios(url, {
          ...options,
          timeout: 10000,
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Institutional-Research-Agent',
            ...options.headers
          }
        });
        return response.data;
      } catch (error) {
        console.error(`[FetchUtils] Attempt ${i + 1} failed for ${url}: ${error.message}`);
        if (i === retries - 1) throw new Error(`Failed to fetch from ${url} after ${retries} attempts`);
        // Exponential backoff
        await new Promise(resolve => setTimeout(resolve, 1000 * Math.pow(2, i)));
      }
    }
  }

  // Placeholder for specific sources
  static async fetchYahooFinance(ticker) {
    // Implement yahoo finance API logic
    return { data: 'mocked data' };
  }
}

module.exports = FetchUtils;
