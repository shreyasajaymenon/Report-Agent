const Orchestrator = require('./orchestrator');

async function main() {
  const companyName = process.argv[2];
  
  if (!companyName) {
    console.error('Usage: node src/index.js "Company Name"');
    console.error('Example: node src/index.js "Tata Motors"');
    process.exit(1);
  }

  console.log(`\n======================================================`);
  console.log(` INITIALIZING REPORT AGENT SWARM FOR: ${companyName}`);
  console.log(`======================================================\n`);

  const orchestrator = new Orchestrator(companyName);
  await orchestrator.runAgents();
}

main();
