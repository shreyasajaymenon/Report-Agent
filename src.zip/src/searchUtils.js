const axios = require('axios');
require('dotenv').config();

class SearchUtils {
  static getLangSearchKeys() {
    if (!this.langSearchKeys) {
      this.langSearchKeys = Object.keys(process.env)
        .filter(key => key.startsWith('LANGSEARCH_API_KEY'))
        .map(key => process.env[key])
        .filter(Boolean);
      this.currentKeyIndex = 0;
    }
    return this.langSearchKeys;
  }

  static async searchAndScrape(query, limit = 5) {
    console.log(`[SearchUtils] Searching web via LangSearch for: "${query}"`);
    const keys = this.getLangSearchKeys();
    
    if (!keys || keys.length === 0) {
      console.warn('[SearchUtils] No LANGSEARCH_API_KEY found. Skipping web search.');
      return 'No web context available (Missing API Key).';
    }

    let attempts = 0;
    const maxAttempts = keys.length;

    while (attempts < maxAttempts) {
      const apiKey = keys[this.currentKeyIndex];
      try {
        await new Promise(res => setTimeout(res, 1000));
        
        const response = await axios.post('https://api.langsearch.com/v1/web-search', {
          query: query,
          count: limit
        }, {
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          },
          timeout: 10000
        });

        if (!response.data || !response.data.data || !response.data.data.webPages) {
          throw new Error('Invalid response from LangSearch');
        }

        let aggregatedText = '';
        const results = response.data.data.webPages.value || [];
        const topResults = results.slice(0, limit);
        
        for (const result of topResults) {
          aggregatedText += `\n\n--- Source: ${result.url || 'Unknown'} ---\n`;
          const content = result.summary || result.snippet || result.description || '';
          aggregatedText += content.substring(0, 3000);
        }
        
        return aggregatedText;

      } catch (error) {
        const isRateLimit = error.response && error.response.status === 429;
        const status = error.response ? error.response.status : 'Unknown';
        console.warn(`[SearchUtils] Key index ${this.currentKeyIndex} failed (Status: ${status}). Rotating to next key...`);
        
        // Rotate to the next key
        this.currentKeyIndex = (this.currentKeyIndex + 1) % keys.length;
        attempts++;

        if (attempts >= maxAttempts) {
          console.error(`[SearchUtils] ALL keys failed. Returning empty string.`);
          return '';
        }
      }
    }
    return '';
  }
}

module.exports = SearchUtils;
