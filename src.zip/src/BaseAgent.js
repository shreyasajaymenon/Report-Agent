const llmClient = require('./llmClient');
const CitationTracker = require('./citationTracker');

class BaseAgent {
  constructor(agentName, systemPrompt, useOpenRouter = true) {
    this.agentName = agentName;
    this.systemPrompt = systemPrompt;
    this.useOpenRouter = useOpenRouter;
    this.citationTracker = new CitationTracker();
  }

  async invoke(userPrompt, schema = null) {
    console.log(`[${this.agentName}] Starting execution...`);
    
    const messages = [
      { role: 'system', content: this.systemPrompt },
      { role: 'user', content: userPrompt }
    ];

    const options = {
      messages,
      temperature: 0.1,
    };

    // If a Zod schema is provided, we can enforce JSON mode output
    if (schema) {
      options.response_format = { type: 'json_object' };
      // Ensure the prompt explicitly asks for JSON
      messages[1].content += '\n\nYou must return your answer in valid JSON matching the provided schema structure.';
    }

    try {
      const response = await llmClient.getCompletion(options, this.useOpenRouter);
      let output = response.content;

      if (schema && output) {
        try {
          const parsed = JSON.parse(output);
          // Auto-track citations if facts exist in the schema
          if (parsed.facts && Array.isArray(parsed.facts)) {
            parsed.facts.forEach(fact => {
              this.citationTracker.addFact(
                fact.claim, 
                fact.sourceUrl, 
                fact.evidence, 
                fact.valuationImpact
              );
            });
          }
          return parsed;
        } catch (parseError) {
          console.error(`[${this.agentName}] Failed to parse JSON response:`, parseError.message);
          return null;
        }
      }
      return output;
    } catch (error) {
      console.error(`[${this.agentName}] Execution failed:`, error.message);
      throw error;
    }
  }
  
  getCitations() {
    return this.citationTracker.getFacts();
  }
}

module.exports = BaseAgent;
